<?php
class Globals {
    const app = 'FACCR';
    const version= '1.0';
    const cssversion= "1.0";
    static $config="";    
    
    // public static function ConfiguracionIni(){     
    //     if (file_exists('../../ini/config.ini')) {
    //         self::$config = parse_ini_file('../../ini/config.ini',true); 
    //     } 
    //     else if (file_exists('../ini/config.ini')) {
    //         self::$config = parse_ini_file('../ini/config.ini',true); 
    //     }
    //     else if (file_exists('../../../ini/config.ini')) {
    //         self::$config = parse_ini_file('../../../ini/config.ini',true); 
    //     }   
    // }  
}
?>